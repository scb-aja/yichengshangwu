﻿#include <iostream>
#include <windows.h>
#include <iomanip>
const int MAX_EMPLOYEES = 100; // 最大职工数量
const int MAX_SALARIES = 6;    // 最大工资项目数量
int numEmployees = 6; // 当前职工数量
// 职工工资信息表
double salaries[MAX_EMPLOYEES][MAX_SALARIES] = {
	{2301, 1235, 798, 1980, 260,200},
	{2302, 1165, 648, 1350, 250,200},
	{2303, 885, 442, 980, 200,150},
	{2304, 1375, 875, 2100, 280,200},
	{2305, 773, 396, 840, 200,150},
	{2306, 1525, 910, 2050, 300,200},
};
const std::string colums[MAX_SALARIES] = {"工号","基本工资","职务工资","津贴","生活补助","交通补贴" };
//************************************
// Method:    getColumsIndx
// FullName:  getColumsIndx
// Access:    public 
// Returns:   int 返回数组索引 -1代表不存在
// Qualifier:
// Author:    
// Parameter: std::string * colums colums数组
// Parameter: int len 数组长度
// Parameter: const std::string & columName 列的名称
//************************************
int getColumsIndx(const std::string* colums, int len,const std::string& columName) {
	for (int i = 0; i < len; i++) {
		if (colums[i] == columName)
			return i;
	}
	return -1;

}
/*查询单项工资*/
void querySingleSalary() {
	int empId;
	std::string salaryName;

	std::cout << "请输入工号和工资名称（用空格分隔）：";
	std::cin >> empId >> salaryName;
	int idx = getColumsIndx(colums, MAX_SALARIES, salaryName);
	if (idx == -1) {
		std::cout << "工资名称不存在!\n";
	}
	double total = 0; /*计算该工资总和*/
	bool isFind = false; /*true 代表存在id，false不存在*/
	for (int i = 0; i < numEmployees; i++) 
	{
		if (salaries[i][0] == empId) 
		{
			std::cout << empId << "的" << salaryName << "为: " << salaries[i][idx] << "\n";
			isFind = true;

		}
		total += salaries[i][idx];
	}
	if (!isFind) {
		std::cout << "输入的id不存在请重新输入!\n";
		return;
	}
	double average = total / numEmployees;
	std::cout << "所有职工的" << salaryName << "的平均工资为：" << average << std::endl;

}
// 查询总工资
void queryTotalSalary() {
	int empId;

	std::cout << "请输入工号：";
	std::cin >> empId;
	bool isFind = false;
	double total = 0; /*id 总工资*/
	double all_total = 0; /*所有总工资*/
	int count = 0;

	for (int i = 0; i < numEmployees; i++) {
		if (salaries[i][0] == empId) {
			isFind = true; /*存在id*/
			for (int j = 1; j < MAX_SALARIES; j++) {
				total += salaries[i][j];
				count++;
			}
		}
		/*累加*/
		for (int j = 1; j < MAX_SALARIES; j++) {
			all_total += salaries[i][j];
			
		}
	}
	if (!isFind) {
		std::cout << "输入的id不存在请重新输入!\n";
		return;
	}
	double average = total / numEmployees;
	std::cout << "工号" << empId << "的总工资为：" << total << std::endl;
	std::cout << "所有职工的总工资的平均工资为：" << average << std::endl;
}

// 4.查询工资排名
void querySalaryRanking() {
	int empId;

	std::cout << "请输入工号：";
	std::cin >> empId;

	double total = 0;
	bool isFind = false;
	for (int i = 0; i < numEmployees; i++) {
		if (salaries[i][0] == empId) {
			for (int j = 1; j < MAX_SALARIES; j++) {
				total += salaries[i][j];
				isFind = true;
			}
		}
	}
	/*先判断是否存在id*/
	if (!isFind) {
		std::cout << "id不存在!\n";
		return;
	}
	
	/*动态申请二维数组 arr[][0] id arr[][1]总工资*/
	double** arr = new double*[numEmployees]; //申请行
	for (int i = 0; i < numEmployees; i++) {
		arr[i] = new double[2];  //每行中个数
		arr[i][0] = arr[i][1] = 0;
	}
	/*计算每个人的总工资 并存入到开辟的新数组当中*/
	for (int i = 0; i < numEmployees; i++) {
		double tempTotal = 0;

		for (int j = 1; j < MAX_SALARIES; j++) {
			tempTotal += salaries[i][j];
		}
		arr[i][0] = salaries[i][0];
		arr[i][1] = tempTotal;
	}
	/*对二维数组 按照每个人总工资排序 采用的是冒泡排序*/
	for (int i = 0; i < numEmployees - 1; i++) {
		for (int j = 0; j < numEmployees - 1 - i; j++) {
			if (arr[j][1] < arr[j + 1][1]) { /*降序*/
				double temp = 0;
				/*交换Id*/
				temp = arr[j][0];
				arr[j][0] = arr[j + 1][0]; 
				arr[j + 1][0] = temp;
				/*交换工资*/
				temp = arr[j][1];
				arr[j][1] = arr[j + 1][1];
				arr[j + 1][1] = temp;
			}
		}
	}
	for (int i = 0; i < numEmployees; i++) {
		if(arr[i][0] == empId)
			std::cout << "工号" << arr[i][0] << " 工资为: " << arr[i][1] << " 其总工资排名为：" << i + 1 << "\n";

	}
	std::cout << "--------------\n";
	for (int i = 0; i < numEmployees; i++) {
		std::cout << "工号" << arr[i][0] << " 工资为: "<< arr[i][1] << " 其总工资排名为：" << i + 1 << "\n";

	}
	/*释放动态申请的数组*/
	for (int i = 0; i < numEmployees; i++)
		delete[] arr[i];
	delete[] arr;
}
// 修改工资
void modifySalary() {
	int empId;
	std::string salaryName;

	std::cout << "请输入工号和工资名称（用空格分隔）：";
	std::cin >> empId >> salaryName;
	bool isFind = false; /*true 存在id false 不存在*/
	double oldSalary = 0;
	double newSalary = 0;
	int cIdx = getColumsIndx(colums, MAX_SALARIES, salaryName); /*获取列明索引*/
	if (cIdx == -1) {
		std::cout << "工资名称不存在\n";
		return;
	}
	for (int i = 0; i < numEmployees; i++) {
		if (salaries[i][0] == empId) {
			isFind = true;
			oldSalary = salaries[i][cIdx];
			std::cout << "请输入修改后的职务工资：";
			std::cin >> newSalary;
			if (newSalary <= 0) {
				std::cout << "工资不能 <= 0 \n";
				return;
			}
			salaries[i][cIdx] = newSalary;
		}
	}

	std::cout << "工号" << empId << "的" << salaryName << "修改前金额为：" << oldSalary << std::endl;
	std::cout << "工号" << empId << "的" << salaryName << "修改后金额为：" << newSalary << std::endl;
}

// 显示菜单
void showMenu() {
	std::cout << "工资管理程序菜单：" << std::endl;
	std::cout << "A 查询单项工资" << std::endl;
	std::cout << "B 查询总工资" << std::endl;
	std::cout << "C 查询工资排名" << std::endl;
	std::cout << "D 修改工资" << std::endl;
	std::cout << "请选择功能（A/B/C/D）：";
}
int main() {
	char choice;
	while (true) {
		showMenu();
		std::cin >> choice;

		switch (choice) {
		case 'A':
			querySingleSalary();
			break;
		case 'B':
			queryTotalSalary();
			break;
		case 'C':
			querySalaryRanking();
			break;
		case 'D':
			modifySalary();
			break;
		default:
			std::cout << "无效的选项！" << std::endl;
			break;
		}

		Sleep(3 * 1000); // 等待3秒
		system("cls"); // 清屏
	}

	return 0;
}
